SADA AL MADINAH — GITHUB BUILD FIXED SOURCE

IMPORTANT: The contents of this ZIP are placed directly at the GitHub repository root.
After uploading, these must be visible at the top level:
- app/
- build.gradle.kts
- settings.gradle.kts
- gradle.properties
- .github/workflows/build-apk.yml

The GitHub Actions workflow intentionally has NO working-directory setting.
It runs `gradle assembleDebug` from the repository root. This fixes the previous
error where Actions tried to enter a non-existent `SadaAlMadinah` subdirectory.

Build steps:
1. Extract this ZIP.
2. Upload the CONTENTS of this ZIP directly to the ROOT of the repository.
   Do not upload an extra enclosing SadaAlMadinah folder.
3. If an old .github/workflows/main.yml exists and has `working-directory: SadaAlMadinah`,
   delete that old workflow or remove the working-directory line to avoid running
   two conflicting workflows.
4. Commit/push to main or master.
5. GitHub > Actions > Build Sada Al Madinah APK.
6. Download artifact `SadaAlMadinah-debug-apk` after a successful run.

Included app behavior:
- Small top-right menu button.
- বাংলা / English / العربية language selection.
- Hotel name editor; empty names are rejected and saved name is stored locally.
- Welcome card preview/JPG uses the custom hotel name. Saving a name refreshes an
  already-open welcome card; language changes also refresh it.
- A render guard prevents an older generated image from overwriting a newer card.

Build notes:
- Android Gradle Plugin 8.5.2, Kotlin 1.9.24, Java 17, Gradle 8.7.
- Workflow builds a DEBUG APK. Signed release builds require signing credentials.
- Android build has not been executed in this environment; GitHub Actions must
  confirm the final Android compilation.
