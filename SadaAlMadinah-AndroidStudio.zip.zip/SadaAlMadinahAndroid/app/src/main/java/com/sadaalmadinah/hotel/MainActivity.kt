package com.sadaalmadinah.hotel

import android.app.*
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.DecimalFormat
import java.util.Locale

data class Room(
    var number:String, var customer:String, var phone:String, var daily:Double,
    var currency:String, var start:Long, var end:Long, var paid:Double
)

class MainActivity : Activity() {
    private val rooms = mutableListOf<Room>()
    private var lang = "bn"
    private var rate = 33.0 // editable SAR per 1,000 BDT equivalent; initial illustrative rate
    private lateinit var body: LinearLayout
    private val green = Color.rgb(23,107,85)
    private val file by lazy { File(filesDir, "hotel_rooms.json") }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        load()
        render()
    }
    private fun s(bn:String, ar:String) = if(lang=="bn") bn else ar
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun label(text:String, size:Float=15f, bold:Boolean=false): TextView =
        TextView(this).apply { this.text=text; textSize=size; setTextColor(Color.rgb(35,45,42)); if(bold) setTypeface(null,Typeface.BOLD); setPadding(dp(4),dp(5),dp(4),dp(5)) }
    private fun button(text:String, action:()->Unit): Button = Button(this).apply { this.text=text; setOnClickListener { action() } }
    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL; setPadding(dp(12),dp(8),dp(12),dp(8))
        setBackgroundColor(Color.WHITE)
        elevation=dp(2).toFloat()
        val p=LinearLayout.LayoutParams(-1,-2); p.setMargins(0,dp(7),0,dp(7)); layoutParams=p
    }
    private fun render() {
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(246,248,247)); setPadding(dp(14),dp(12),dp(14),dp(12)) }
        val top=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        val title=label("Sada Al Madinah",20f,true); title.setTextColor(green); top.addView(title, LinearLayout.LayoutParams(0,-2,1f))
        top.addView(button(if(lang=="bn") "العربية" else "বাংলা") { lang=if(lang=="bn") "ar" else "bn"; render() })
        root.addView(top)
        root.addView(label(s("Hotel Room Rent Hisab","حساب إيجار غرف الفندق"),16f,true))
        val total=rooms.sumOf { cost(it) }; val paid=rooms.sumOf { it.paid }; val remain=total-paid
        val summary=card()
        summary.addView(label("${s("মোট ভাড়া","إجمالي الإيجار")}: ${money(total,"BDT")}"))
        summary.addView(label("${s("মোট জমা","إجمالي المدفوع")}: ${money(paid,"BDT")}"))
        summary.addView(label("${s("মোট বাকি","المبلغ المتبقي")}: ${money(remain,"BDT")}"))
        summary.addView(label(s("রূপান্তর হার (১ SAR = কত BDT)","سعر التحويل (١ ريال = كم تاكا)")+": ${rate} BDT"))
        summary.addView(button(s("বিনিময় হার পরিবর্তন","تعديل سعر الصرف")) { rateDialog() })
        root.addView(summary)
        root.addView(button(s("+ নতুন রুম যোগ করুন","+ إضافة غرفة جديدة")) { roomDialog(null) })
        body=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        val scroll=ScrollView(this); scroll.addView(body)
        rooms.forEach { r ->
            val c=card()
            c.addView(label("${s("রুম নং","رقم الغرفة")} ${digits(r.number)}",18f,true))
            c.addView(label("${s("কাস্টমারের নাম","اسم العميل")}: ${r.customer}"))
            c.addView(label("${s("মোবাইল নম্বর","رقم الجوال")}: ${r.phone}"))
            c.addView(label("${s("দৈনিক ভাড়া","الإيجار اليومي")}: ${money(r.daily,r.currency)}"))
            c.addView(label("${s("মোট ভাড়া","إجمالي الإيجار")}: ${money(cost(r),r.currency)}"))
            c.addView(label("${s("জমা","المدفوع")}: ${money(r.paid,r.currency)}"))
            c.addView(label("${s("বাকি","المتبقي")}: ${money(cost(r)-r.paid,r.currency)}"))
            c.addView(label("${s("শুরু","البداية")}: ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(r.start))}"))
            c.addView(label("${s("শেষ","النهاية")}: ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(r.end))}"))
            val actions=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
            actions.addView(button(s("এডিট","تعديل")) { roomDialog(r) }, LinearLayout.LayoutParams(0,-2,1f))
            actions.addView(button("+১ দিন") { r.end+=86400000; save(); render() }, LinearLayout.LayoutParams(0,-2,1f))
            actions.addView(button("−১ দিন") { r.end-=86400000; save(); render() }, LinearLayout.LayoutParams(0,-2,1f))
            actions.addView(button(s("মুছুন","حذف")) { rooms.remove(r); save(); render() }, LinearLayout.LayoutParams(0,-2,1f))
            c.addView(actions); body.addView(c)
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
    }
    private fun digits(v:String):String = if(lang=="ar") v.map { if(it in '0'..'9') ('٠'.code+it.code-'0'.code).toChar() else it }.joinToString("") else v
    private fun money(amount:Double, currency:String):String {
        val value= if(currency=="SAR") amount else amount
        val symbol=if(currency=="SAR") "ر.س" else "৳"
        val fmt=DecimalFormat("#,##0.##").format(value)
        return if(lang=="ar") "${digits(fmt)} $symbol" else "$symbol $fmt"
    }
    private fun cost(r:Room):Double {
        val days=((r.end-r.start).coerceAtLeast(0)/86400000.0)
        return kotlin.math.ceil(days)*r.daily
    }
    private fun rateDialog() {
        val input=EditText(this); input.inputType=8194; input.setText(rate.toString())
        AlertDialog.Builder(this).setTitle(s("১ SAR = কত BDT?","١ ريال = كم تاكا؟")).setView(input)
            .setPositiveButton(s("সংরক্ষণ","حفظ")) { _,_-> rate=input.text.toString().toDoubleOrNull() ?: rate; save(); render() }
            .setNegativeButton(s("বাতিল","إلغاء"),null).show()
    }
    private fun roomDialog(old:Room?) {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(18),dp(8),dp(18),dp(4)) }
        fun field(hint:String, value:String=""):EditText { val e=EditText(this); e.hint=hint; e.setText(value); box.addView(e); return e }
        val number=field(s("রুম নং","رقم الغرفة"),old?.number ?: "")
        val customer=field(s("কাস্টমারের নাম","اسم العميل"),old?.customer ?: "")
        val phone=field(s("মোবাইল নম্বর","رقم الجوال"),old?.phone ?: "")
        val daily=field(s("দৈনিক ভাড়া","الإيجار اليومي"),old?.daily?.toString() ?: "")
        val paid=field(s("জমার পরিমাণ","المبلغ المدفوع"),old?.paid?.toString() ?: "0")
        val currency=Spinner(this)
        currency.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("BDT - ৳","SAR - ر.س"))
        currency.setSelection(if(old?.currency=="SAR") 1 else 0); box.addView(currency)
        val start=field(s("শুরুর তারিখ/সময় (YYYY-MM-DD HH:MM)","تاريخ ووقت البداية"), old?.let { java.text.SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(java.util.Date(it.start)) } ?: "")
        val end=field(s("শেষের তারিখ/সময় (YYYY-MM-DD HH:MM)","تاريخ ووقت النهاية"), old?.let { java.text.SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(java.util.Date(it.end)) } ?: "")
        AlertDialog.Builder(this).setTitle(s("রুমের তথ্য","بيانات الغرفة")).setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton(s("সংরক্ষণ","حفظ")) { _,_->
                val n=number.text.toString().trim()
                val df=java.text.SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US)
                val st=runCatching { df.parse(start.text.toString())!!.time }.getOrNull()
                val en=runCatching { df.parse(end.text.toString())!!.time }.getOrNull()
                if(n.isNotEmpty() && customer.text.isNotEmpty() && daily.text.toString().toDoubleOrNull()!=null && st!=null && en!=null) {
                    if(rooms.any { it.number==n && it!==old }) { Toast.makeText(this,s("এই রুম নম্বর আগে আছে","رقم الغرفة موجود بالفعل"),Toast.LENGTH_LONG).show(); return@setPositiveButton }
                    val r=old ?: Room(n,"","",0.0,"BDT",st,en,0.0)
                    r.number=n; r.customer=customer.text.toString(); r.phone=phone.text.toString()
                    r.daily=daily.text.toString().toDouble(); r.paid=paid.text.toString().toDoubleOrNull()?:0.0
                    r.currency=if(currency.selectedItemPosition==1) "SAR" else "BDT"; r.start=st; r.end=en
                    if(old==null) rooms.add(r); save(); render()
                } else Toast.makeText(this,s("প্রয়োজনীয় তথ্য সঠিকভাবে দিন","يرجى إدخال البيانات بشكل صحيح"),Toast.LENGTH_LONG).show()
            }.setNegativeButton(s("বাতিল","إلغاء"),null).show()
    }
    private fun save() {
        val arr=JSONArray()
        rooms.forEach { r -> arr.put(JSONObject().put("number",r.number).put("customer",r.customer).put("phone",r.phone).put("daily",r.daily).put("currency",r.currency).put("start",r.start).put("end",r.end).put("paid",r.paid)) }
        file.writeText(JSONObject().put("rooms",arr).put("sarToBdt",rate).toString())
    }
    private fun load() {
        runCatching {
            if(file.exists()) {
                val o=JSONObject(file.readText()); rate=o.optDouble("sarToBdt",33.0)
                val a=o.getJSONArray("rooms")
                for(i in 0 until a.length()) { val x=a.getJSONObject(i); rooms.add(Room(x.getString("number"),x.optString("customer"),x.optString("phone"),x.getDouble("daily"),x.optString("currency","BDT"),x.getLong("start"),x.getLong("end"),x.optDouble("paid"))) }
            }
        }
    }
}
