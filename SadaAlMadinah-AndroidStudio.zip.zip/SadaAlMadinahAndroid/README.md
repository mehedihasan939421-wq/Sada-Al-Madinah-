# Sada Al Madinah Android project

This is an Android Studio source project (Kotlin, no SQLite, no Firebase, no Supabase).
Room/customer records are stored as a private JSON file in the app's internal files directory.

## Build
1. Open this folder in Android Studio (Giraffe or newer).
2. Allow Gradle sync; Android SDK 35 and JDK 17 are required.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Important scope notes
- This is a functional starter implementation, not a finished production release.
- The UI follows the supplied PDF's information hierarchy, but pixel-perfect reproduction still needs visual QA against the original PDF.
- Exchange conversion currently stores an editable illustrative rate (default 33 BDT per SAR); live rates are not fetched yet. The current screen summarizes in BDT and individual room records retain their selected currency.
- Alarm scheduling, PDF export, full conversion display, backups/restores, and production-grade Arabic typography are not yet implemented.
- No data is transmitted; no network permission is declared. JSON data stays in app-private storage and is lost if app data is cleared/uninstalled unless exported/backed up.
