package com.hotel.rent

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.ClipData
import android.util.Base64
import androidx.core.content.FileProvider
import java.io.File
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF0F5C55.toInt()
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.blockNetworkLoads = false
        web.settings.loadsImagesAutomatically = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.scheme == "tel") {
                    startActivity(Intent(Intent.ACTION_DIAL, u))
                    return true
                }
                if (u.host == "wa.me" || u.scheme == "whatsapp") {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, u))
                    } catch (e: Exception) {
                    }
                    return true
                }
                return false
            }
        }
        web.addJavascriptInterface(Bridge(applicationContext, web), "Android")
        web.loadUrl("file:///android_asset/index.html")
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        askExact()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.__back&&window.__back())===true") { r ->
            if (r != "true") {
                if (web.canGoBack()) web.goBack() else finish()
            }
        }
    }

    private fun askExact() {
        if (Build.VERSION.SDK_INT >= 31) {
            val am = getSystemService(ALARM_SERVICE) as AlarmManager
            if (!am.canScheduleExactAlarms()) {
                try {
                    startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
                } catch (e: Exception) {
                }
            }
        }
    }
}

class Bridge(private val c: Context, private val web: WebView) {
    private fun parseEnd(s: String): Long = try {
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).parse(s)?.time ?: 0L
    } catch (e: Exception) {
        0L
    }

    @JavascriptInterface
    fun sync(json: String) {
        try {
            val o = JSONObject(json)
            val lang = o.optString("lang", "bn")
            val arr = o.getJSONArray("rooms")
            val list = mutableListOf<Item>()
            for (i in 0 until arr.length()) {
                val r = arr.getJSONObject(i)
                val end = parseEnd(r.optString("end"))
                if (end > 0) list.add(Item(r.getString("id"), r.optString("room"), r.optString("name"), end))
            }
            Alarms.sync(c, lang, list)
        } catch (e: Exception) {
        }
    }

    @JavascriptInterface
    fun print(title: String) {
        web.post {
            try {
                val pm = web.context.getSystemService(Context.PRINT_SERVICE) as PrintManager
                val name = if (title.isBlank()) "Receipt" else title
                pm.print(name, web.createPrintDocumentAdapter(name), PrintAttributes.Builder().build())
            } catch (e: Exception) {
            }
        }
    }

    @JavascriptInterface
    fun share(text: String) {
        try {
            val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
            c.startActivity(Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
        }
    }

    @JavascriptInterface
    fun shareImage(base64Png: String) {
        try {
            val bytes = Base64.decode(base64Png, Base64.DEFAULT)
            val dir = File(c.cacheDir, "shared").apply { mkdirs() }
            val file = File(dir, "SadaAlMadinah-Welcome.png")
            file.writeBytes(bytes)
            val uri = FileProvider.getUriForFile(c, c.packageName + ".fileprovider", file)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = ClipData.newUri(c.contentResolver, "Welcome card", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val whatsapp = c.packageManager.getLaunchIntentForPackage("com.whatsapp")
            if (whatsapp != null) {
                send.setPackage("com.whatsapp")
                send.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                c.startActivity(send)
            } else {
                c.startActivity(Intent.createChooser(send, "Share welcome card").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        } catch (e: Exception) {
        }
    }

    @JavascriptInterface
    fun test() {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val i = Intent(c, AlarmReceiver::class.java).putExtra("id", "-test").putExtra("kind", 1)
        val pi = PendingIntent.getBroadcast(c, 7, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        try {
            am.setAlarmClock(AlarmManager.AlarmClockInfo(System.currentTimeMillis() + 5000, pi), pi)
        } catch (e: SecurityException) {
        }
    }
}
