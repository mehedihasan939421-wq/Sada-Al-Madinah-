Sada Al Madinah - Hotel Room Rent Management (Android)

অ্যাপের মূল ডিজাইন: app/src/main/assets/index.html
অ্যালার্ম: নেটিভ Android AlarmManager দিয়ে কাজ করে, অ্যাপ বন্ধ থাকলেও।
রুম ম্যানেজমেন্ট, ভাড়া, জমা, বাকি, ভাষা পরিবর্তন (বাংলা/আরবি/ইংরেজি) এবং অন্যান্য আগের ফিচার রাখা হয়েছে।

WELCOME CARD
- বিল/রিসিট নয়: অতিথিকে স্বাগতম জানানো Premium Welcome Card।
- কার্ডটি উচ্চ রেজোলিউশনের PNG ছবি হিসেবে তৈরি হয়।
- কার্ডে বড় করে হোটেলের নাম, স্বাগতম, অতিথির নাম, আবার আসার আমন্ত্রণ এবং নিরাপদ যাত্রার শুভেচ্ছা থাকে।
- Welcome Card-এর WhatsApp বাটন PNG ছবিটি WhatsApp-এ শেয়ার করে।
- রুমের কার্ডে কাস্টমারের মোবাইল নম্বরের পাশের WhatsApp লোগোতে চাপ দিলে ওই নম্বরের WhatsApp chat খোলে।
- WhatsApp chat খোলার জন্য নম্বরটি আন্তর্জাতিক ফরম্যাটে থাকা প্রয়োজন। সৌদি 05xxxxxxxx এবং বাংলাদেশি 01xxxxxxxxx নম্বর স্বয়ংক্রিয়ভাবে country code-এ রূপান্তর করা হয়।
- Welcome Card template: Bengali 9:16 premium artwork (no template number printed).
- Guest name is dynamically rendered inside the emerald nameplate for each customer.


Welcome Card design update:
- Uses the latest user-supplied Bengali 9:16 artwork as the visual background.
- The green-and-gold guest nameplate is blank in the bundled background and personalized at runtime.
- WhatsApp welcome sharing sends the generated PNG image.
