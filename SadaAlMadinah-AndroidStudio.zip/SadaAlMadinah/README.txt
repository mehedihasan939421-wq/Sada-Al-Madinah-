Sada Al Madinah - Hotel Room Rent Hisab (Android)
অ্যাপের ডিজাইন app/src/main/assets/index.html ফাইলে (ওয়েব ডেমোর হুবহু একই)।
অ্যালার্ম নেটিভ Android AlarmManager দিয়ে বাজে, অ্যাপ বন্ধ থাকলেও।
বিল রিসিট: ভাড়ার মেয়াদ শেষ হলে (বা রুম খালি করলে) রুমের কার্ডে "বিল রিসিট" বোতাম আসে।
রিসিটে রসিদ নং, অতিথির নাম, তারিখ, দিন, ভাড়া, জমা ও বাকি থাকে; হোয়াটসঅ্যাপ/শেয়ার/প্রিন্ট(PDF)/কপি করা যায়।


WELCOME CARD UPDATE
- Welcome messages are rendered as a premium PNG image.
- WhatsApp buttons share the PNG image (not a plain text message).
- Bengali, English and Arabic welcome cards are supported.
