Sada Al Madinah - Hotel Room Rent Management (Android)

মূল অ্যাপের ডিজাইন ও বিদ্যমান ফিচার:
- app/src/main/assets/index.html
- বাংলা, আরবি ও ইংরেজি ভাষা
- রুম ম্যানেজমেন্ট, ভাড়া, জমা, বাকি এবং অ্যালার্ম
- নেটিভ Android AlarmManager

WELCOME CARD
- WhatsApp-এ পাঠানোর জন্য একটি মাত্র সম্পূর্ণ Welcome Card ছবি তৈরি হয়।
- কার্ডের ভেতরেই হোটেলের নাম, স্বাগতম বার্তা, ধন্যবাদ, আবার আসার আমন্ত্রণ এবং নিরাপদ যাত্রার শুভেচ্ছা লেখা থাকে।
- সব লেখা কার্ডের ডিজাইনের অংশ; আলাদা টেক্সট মেসেজ বা দ্বিতীয় ছবি অ্যাটাচ করা হয় না।
- সবুজ নামের প্লেটে বর্তমান কাস্টমারের নাম স্বয়ংক্রিয়ভাবে বসে।
- কার্ডটি JPEG (768x1152, quality 78%) হিসেবে তৈরি হয় এবং WhatsApp বা WhatsApp Business-এ একবারে একটি image attachment হিসেবে শেয়ার হয়।
- শেয়ার করার আগে ছবিটি শুধু অ্যাপের cache-এ অস্থায়ীভাবে থাকে; Gallery বা Downloads-এ সেভ হয় না।
- WhatsApp-এর নিজস্ব Send বোতাম ব্যবহারকারীকে চাপতে হবে।

TEMPLATE
- app/src/main/assets/welcome-template-custom.png হলো সম্পূর্ণ বাংলা Welcome Card artwork।
- সব স্বাগতম বার্তা artwork-এর মধ্যেই আছে; শুধু সবুজ নামের প্লেটে কাস্টমারের নাম runtime-এ বসানো হয়।

BUILD
- Android Studio-তে SadaAlMadinah ফোল্ডারটি Open করুন এবং Gradle Sync সম্পন্ন করে APK Build করুন।
- বাস্তব ফোনে WhatsApp/WhatsApp Business দিয়ে শেয়ার পরীক্ষা করুন।
