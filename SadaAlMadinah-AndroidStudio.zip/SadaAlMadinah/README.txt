Sada Al Madinah - Hotel Room Rent Management (Android)

মূল অ্যাপের ডিজাইন ও বিদ্যমান ফিচার:
- app/src/main/assets/index.html
- বাংলা, আরবি ও ইংরেজি ভাষা
- রুম ম্যানেজমেন্ট, ভাড়া, জমা, বাকি এবং অ্যালার্ম
- নেটিভ Android AlarmManager

WELCOME CARD (UPDATED)
- Welcome Card কোনো ডাউনলোড করা JPG/PNG ব্যাকগ্রাউন্ডের ওপর নির্ভর করে না।
- HTML Canvas-এর ভেক্টর ড্রয়িং, গ্রেডিয়েন্ট, ইসলামিক অলংকরণ ও বাংলা ফন্ট দিয়ে ডিজাইনটি অ্যাপের ভেতরেই তৈরি হয়।
- কার্ডে হোটেলের নাম, আন্তরিক স্বাগতম, কাস্টমারের নাম, ধন্যবাদ, পুনরায় আসার আমন্ত্রণ এবং নিরাপদ যাত্রার শুভেচ্ছা থাকে।
- কার্ডে কোনো টাকা, ভাড়া, জমা, রুম নম্বর বা তারিখ যোগ করা হয় না।
- প্রতিবার কাস্টমারের নাম অনুযায়ী একটি মাত্র JPEG তৈরি হয়।
- WhatsApp বা WhatsApp Business-এ ACTION_SEND দিয়ে একটি image/jpeg attachment পাঠানো হয়।
- শেয়ার করার আগে JPEG শুধু অ্যাপের cache-এ অস্থায়ীভাবে থাকে; Gallery বা Downloads-এ সেভ হয় না।
- WhatsApp-এর নিজস্ব Send বোতাম ব্যবহারকারীকে চাপতে হবে।
- পুরোনো welcome-template image assets সরিয়ে দেওয়া হয়েছে।

BUILD
- Android Studio-তে SadaAlMadinah ফোল্ডারটি Open করুন এবং Gradle Sync সম্পন্ন করে APK Build করুন।
- বাস্তব ফোনে WhatsApp/WhatsApp Business দিয়ে শেয়ার পরীক্ষা করুন।
