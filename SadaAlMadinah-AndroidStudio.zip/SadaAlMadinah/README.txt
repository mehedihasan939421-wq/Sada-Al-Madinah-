Sada Al Madinah - Hotel Room Rent Hisab (Android Studio project)

1) Android Studio (Koala বা নতুন) ইনস্টল করুন
2) File > Open > SadaAlMadinah ফোল্ডার খুলুন, Gradle Sync শেষ হতে দিন (ইন্টারনেট লাগবে)
3) ফোনে USB debugging চালু করে Run চাপুন, অথবা Build > Build APK(s)

ফন্ট:
- বাংলা: কালপুরুষ (app/src/main/res/font/kalpurush.ttf) অ্যাপের ভেতরেই আছে।
- আরবি: ডিফল্টে ফোনের নাসখ ফন্ট। কুরআনের মতো Amiri চাইলে Amiri-Regular.ttf ফাইলটির নাম amiri.ttf করে
  app/src/main/res/font/ ফোল্ডারে রাখুন (কোড বদলাতে হবে না)।
