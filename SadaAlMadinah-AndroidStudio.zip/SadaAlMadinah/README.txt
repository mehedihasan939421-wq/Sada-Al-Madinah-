Sada Al Madinah - Hotel Room Rent Hisab (Android)
অ্যাপের ডিজাইন app/src/main/assets/index.html ফাইলে (ওয়েব ডেমোর হুবহু একই)।
অ্যালার্ম নেটিভ Android AlarmManager দিয়ে বাজে, অ্যাপ বন্ধ থাকলেও।
