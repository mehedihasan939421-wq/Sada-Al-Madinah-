হোটেল মেনু ও নাম পরিবর্তন

প্রাসঙ্গিক ফাইল:
app/src/main/assets/index.html

যে অংশগুলো:
- CSS: #menuToggle, #hotelMenu (হেডারের ডান পাশে মেনু)
- HTML: #menuToggle, #hotelMenu, #editHotelName
- JavaScript: LKEY (ভাষা সংরক্ষণ), HKEY (কাস্টম হোটেল নাম সংরক্ষণ), applyLang(), menuToggle/editHotelName event handlers
- স্বাগতম কার্ড: rcptBuild() ফাংশনের rp-hotel অংশে esc(t("hotel")) ব্যবহার করা হয়েছে; তাই কাস্টম নামও দেখায়।

পরিবর্তন দেখতে এই প্রজেক্ট থেকে অ্যাপটি পুনরায় Build/Run করে ইনস্টল করুন।

সর্বশেষ বাগ ফিক্স:
- Android WebView-এ window.prompt সমর্থিত না থাকায় নাম সম্পাদনার জন্য নিজস্ব ইন-অ্যাপ ডায়ালগ যোগ করা হয়েছে।
- নাম সংরক্ষণ করলে localStorage-এ সেভ হবে এবং হেডার/স্বাগতম কার্ড/JPG কার্ডে আপডেট হবে।
- হ্যামবার্গার মেনু এখন হেডারের একদম ডান পাশের ওপরের কোণায় absolute অবস্থানে থাকবে।
- মেনু আইকন ছোট করে ৩০x৩০ পিক্সেল করা হয়েছে; আইকনের ভেতরের চিহ্ন ১৭ পিক্সেল।
- হোটেলের নাম মেনু থেকে এডিট করে সংরক্ষণ করা যাবে। নামটি হেডার, স্বাগতম কার্ড এবং JPG কার্ডে একইভাবে আপডেট হবে।


অফলাইন ভাষা/হোটেল নাম সিস্টেম:
- কোনো Google Translate/অনলাইন API বা fetch ব্যবহার করা হয় না।
- হোটেলের নাম LocalStorage-এ বাংলা/ইংরেজি/আরবি আলাদা সংস্করণ হিসেবে সংরক্ষণ হয়।
- মেনু থেকে ভাষা বদলালে header, app title, menu, room UI, receipt/welcome card এবং JPG card নির্বাচিত ভাষায় আপডেট হয়।
- নাম বাংলা থেকে ইংরেজি/আরবি, ইংরেজি থেকে বাংলা/আরবি এবং আরবি থেকে বাংলা/ইংরেজি—সব conversion অ্যাপের ভেতরের offline transliteration rules দিয়ে হয়।
- Android WebView network loading বন্ধ রাখা হয়েছে এবং INTERNET/ACCESS_NETWORK_STATE permission সরানো হয়েছে।
