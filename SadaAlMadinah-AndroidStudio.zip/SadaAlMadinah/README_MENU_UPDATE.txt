হোটেল মেনু ও নাম পরিবর্তন

প্রাসঙ্গিক ফাইল:
app/src/main/assets/index.html

যে অংশগুলো:
- CSS: #menuToggle, #hotelMenu (হেডারের ডান পাশে মেনু)
- HTML: #menuToggle, #hotelMenu, #editHotelName
- JavaScript: LKEY (ভাষা সংরক্ষণ), HKEY (কাস্টম হোটেল নাম সংরক্ষণ), applyLang(), menuToggle/editHotelName event handlers
- স্বাগতম কার্ড: rcptBuild() ফাংশনের rp-hotel অংশে esc(t("hotel")) ব্যবহার করা হয়েছে; তাই কাস্টম নামও দেখায়।

পরিবর্তন দেখতে এই প্রজেক্ট থেকে অ্যাপটি পুনরায় Build/Run করে ইনস্টল করুন।

সর্বশেষ বাগ ফিক্স:
- Android WebView-এ window.prompt সমর্থিত না থাকায় নাম সম্পাদনার জন্য নিজস্ব ইন-অ্যাপ ডায়ালগ যোগ করা হয়েছে।
- নাম সংরক্ষণ করলে localStorage-এ সেভ হবে এবং হেডার/স্বাগতম কার্ড/JPG কার্ডে আপডেট হবে।
- হ্যামবার্গার আইকন ৩৪x৩৪ পিক্সেল করা হয়েছে।
