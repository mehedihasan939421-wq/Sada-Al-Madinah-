plugins {
    id("com.android.application")
}
android {
    namespace = "com.hotel.rent"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.hotel.rent"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}


dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
}
