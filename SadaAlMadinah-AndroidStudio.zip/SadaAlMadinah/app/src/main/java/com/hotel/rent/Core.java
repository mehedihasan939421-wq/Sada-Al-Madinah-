package com.hotel.rent;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

final class Core {
    private Core() {}
}

final class Item {
    final String id;
    final String room;
    final String name;
    final long end;

    Item(String id, String room, String name, long end) {
        this.id = id;
        this.room = room;
        this.name = name;
        this.end = end;
    }
}

final class Store {
    private static final String PREFS = "hotel";
    private Store() {}

    private static android.content.SharedPreferences sp(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static String lang(Context c) {
        return sp(c).getString("lang", "bn");
    }

    static List<Item> items(Context c) {
        List<Item> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp(c).getString("items", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                out.add(new Item(o.getString("id"), o.getString("room"), o.getString("name"), o.getLong("end")));
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    static void save(Context c, String lang, List<Item> list) {
        JSONArray a = new JSONArray();
        for (Item it : list) {
            a.put(new JSONObject()
                    .put("id", it.id)
                    .put("room", it.room)
                    .put("name", it.name)
                    .put("end", it.end));
        }
        sp(c).edit().putString("lang", lang).putString("items", a.toString()).apply();
    }
}

final class Alarms {
    private static final long MIN10 = 600000L;
    private Alarms() {}

    private static PendingIntent pi(Context c, Item it, int kind) {
        int code = ((it.id.hashCode() & 0x3fffffff) * 2) + kind;
        Intent i = new Intent(c, AlarmReceiver.class)
                .putExtra("id", it.id)
                .putExtra("kind", kind)
                .putExtra("end", it.end);
        return PendingIntent.getBroadcast(c, code, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void cancelAll(Context c, List<Item> list) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        for (Item it : list) {
            am.cancel(pi(c, it, 0));
            am.cancel(pi(c, it, 1));
        }
    }

    static void scheduleAll(Context c, List<Item> list) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        PendingIntent show = PendingIntent.getActivity(c, 0,
                new Intent(c, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        long now = System.currentTimeMillis();
        for (Item it : list) {
            try {
                if (it.end - MIN10 > now) {
                    am.setAlarmClock(new AlarmManager.AlarmClockInfo(it.end - MIN10, show), pi(c, it, 0));
                }
                if (it.end > now) {
                    am.setAlarmClock(new AlarmManager.AlarmClockInfo(it.end, show), pi(c, it, 1));
                }
            } catch (SecurityException ignored) {
            }
        }
    }

    static void sync(Context c, String lang, List<Item> list) {
        cancelAll(c, Store.items(c));
        Store.save(c, lang, list);
        scheduleAll(c, list);
    }
}

