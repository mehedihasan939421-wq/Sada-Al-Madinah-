package com.hotel.rent;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView web;
    private static final int LOGO_REQUEST_CODE = 7041;

    @SuppressLint("SetJavaScriptEnabled")
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF0F5C55);
        web = new WebView(this);
        setContentView(web);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setBlockNetworkLoads(true);
        web.getSettings().setLoadsImagesAutomatically(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("tel".equals(u.getScheme())) {
                    startActivity(new Intent(Intent.ACTION_DIAL, u)); return true;
                }
                if ("wa.me".equals(u.getHost()) || "whatsapp".equals(u.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                    return true;
                }
                return false;
            }
        });
        web.addJavascriptInterface(new Bridge(this, web), "Android");
        web.loadUrl("file:///android_asset/index.html");
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        askExact();
    }

    @Override public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != LOGO_REQUEST_CODE || resultCode != RESULT_OK || data == null) return;
        Uri uri = data.getData();
        if (uri == null) return;
        try {
            try (java.io.InputStream in = getContentResolver().openInputStream(uri);
                 FileOutputStream out = new FileOutputStream(new File(getFilesDir(), "app_logo.png"))) {
                if (in == null) throw new IllegalArgumentException("ছবিটি পড়া যায়নি");
                byte[] buf = new byte[8192]; int n;
                while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            }
            Bitmap bitmap;
            try (java.io.InputStream in2 = getContentResolver().openInputStream(uri)) {
                bitmap = BitmapFactory.decodeStream(in2);
            }
            if (bitmap == null) throw new IllegalArgumentException("ছবিটি পড়া যায়নি");
            createOrUpdateLogoShortcut(bitmap);
            Toast.makeText(this, "লোগো সেট হয়েছে। হোম স্ক্রিনের Sada Al Madinah শর্টকাটে এটি দেখা যাবে।", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "লোগো সেট করা যায়নি: " + (e.getLocalizedMessage() == null ? "অজানা সমস্যা" : e.getLocalizedMessage()), Toast.LENGTH_LONG).show();
        }
    }

    private void createOrUpdateLogoShortcut(Bitmap bitmap) {
        if (Build.VERSION.SDK_INT < 26) return;
        ShortcutManager sm = getSystemService(ShortcutManager.class);
        if (sm == null) return;
        String id = "hotel_app_logo";
        Intent intent = new Intent(this, MainActivity.class).setAction(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        ShortcutInfo info = new ShortcutInfo.Builder(this, id)
                .setShortLabel("Sada Hotel").setLongLabel("Sada Al Madinah")
                .setIcon(Icon.createWithBitmap(bitmap)).setIntent(intent).build();
        try {
            boolean pinned = false;
            for (ShortcutInfo s : sm.getPinnedShortcuts()) if (id.equals(s.getId())) { pinned = true; break; }
            if (pinned) sm.updateShortcuts(java.util.Collections.singletonList(info));
            else if (sm.isRequestPinShortcutSupported()) sm.requestPinShortcut(info, null);
            else sm.setDynamicShortcuts(java.util.Collections.singletonList(info));
        } catch (Exception ignored) {
            try { sm.setDynamicShortcuts(java.util.Collections.singletonList(info)); } catch (Exception ignored2) {}
        }
    }

    @Override public void onBackPressed() {
        web.evaluateJavascript("(window.__back&&window.__back())===true", r -> {
            if (!"true".equals(r)) { if (web.canGoBack()) web.goBack(); else finish(); }
        });
    }

    private void askExact() {
        if (Build.VERSION.SDK_INT >= 31) {
            AlarmManager am = (AlarmManager)getSystemService(ALARM_SERVICE);
            if (am != null && !am.canScheduleExactAlarms()) {
                try { startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + getPackageName()))); } catch (Exception ignored) {}
            }
        }
    }
}

class Bridge {
    private final Context c;
    private final WebView web;
    private final StringBuilder imageBuffer = new StringBuilder();

    Bridge(Context c, WebView web) { this.c = c; this.web = web; }

    private long parseEnd(String s) {
        try { java.util.Date d = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).parse(s); return d == null ? 0L : d.getTime(); }
        catch (Exception e) { return 0L; }
    }

    @JavascriptInterface public void chooseLogo() {
        Activity a = c instanceof Activity ? (Activity)c : null;
        if (a == null) return;
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*");
        try { a.startActivityForResult(i, 7041); }
        catch (Exception e) { a.startActivityForResult(new Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 7041); }
    }

    @JavascriptInterface public void sync(String json) {
        try {
            JSONObject o = new JSONObject(json); String lang = o.optString("lang", "bn"); JSONArray arr = o.getJSONArray("rooms");
            List<Item> list = new ArrayList<>();
            for (int i=0;i<arr.length();i++) { JSONObject r=arr.getJSONObject(i); long end=parseEnd(r.optString("end")); if(end>0) list.add(new Item(r.getString("id"),r.optString("room"),r.optString("name"),end)); }
            Alarms.sync(c, lang, list);
        } catch (Exception ignored) {}
    }

    @JavascriptInterface public void print(String title) {
        web.post(() -> { try { PrintManager pm=(PrintManager)web.getContext().getSystemService(Context.PRINT_SERVICE); String name=title.isEmpty()?"Receipt":title; pm.print(name, web.createPrintDocumentAdapter(name), new PrintAttributes.Builder().build()); } catch(Exception ignored) {} });
    }

    @JavascriptInterface public void share(String text) {
        try { Intent send=new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,text); c.startActivity(Intent.createChooser(send,null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); } catch(Exception ignored) {}
    }

    @JavascriptInterface public synchronized void beginShareImage() { imageBuffer.setLength(0); }
    @JavascriptInterface public synchronized void appendShareImageChunk(String chunk) {
        if (chunk.length()>65536) throw new IllegalArgumentException("Image chunk is too large");
        if (imageBuffer.length()+chunk.length()>20*1024*1024) { imageBuffer.setLength(0); throw new IllegalArgumentException("Welcome card image is too large"); }
        imageBuffer.append(chunk);
    }
    @JavascriptInterface public synchronized void cancelShareImage() { imageBuffer.setLength(0); }

    @JavascriptInterface public synchronized void finishShareImage() {
        try {
            String encoded=imageBuffer.toString(); imageBuffer.setLength(0); if(encoded.trim().isEmpty()) throw new IllegalArgumentException("ছবির ডেটা পাওয়া যায়নি");
            byte[] bytes=Base64.decode(encoded,Base64.DEFAULT); if(bytes.length==0) throw new IllegalArgumentException("ছবিটি খালি");
            File dir=new File(c.getCacheDir(),"shared"); if(!dir.exists()) dir.mkdirs(); File[] old=dir.listFiles(); if(old!=null) for(File f:old) f.delete();
            File file=new File(dir,"welcome-"+System.currentTimeMillis()+".jpg"); try(FileOutputStream out=new FileOutputStream(file)){out.write(bytes);}
            Uri uri=FileProvider.getUriForFile(c,c.getPackageName()+".fileprovider",file);
            Intent send=new Intent(Intent.ACTION_SEND).setType("image/jpeg").putExtra(Intent.EXTRA_STREAM,uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);
            String target=null; for(String pkg:new String[]{"com.whatsapp","com.whatsapp.w4b"}) { try { c.getPackageManager().getPackageInfo(pkg,0); target=pkg; break; } catch(Exception ignored) {} }
            if(target!=null) send.setPackage(target);
            final String targetPackage=target;
            web.post(() -> { try { c.startActivity(targetPackage!=null?send:Intent.createChooser(send,"Welcome card শেয়ার করুন").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_GRANT_READ_URI_PERMISSION)); } catch(Exception e) { Toast.makeText(c,"শেয়ার চালু করা যায়নি: "+(e.getLocalizedMessage()==null?"অজানা সমস্যা":e.getLocalizedMessage()),Toast.LENGTH_LONG).show(); } });
        } catch(Exception e) { imageBuffer.setLength(0); web.post(() -> Toast.makeText(c,"ছবি প্রস্তুত করা যায়নি: "+(e.getLocalizedMessage()==null?"অজানা সমস্যা":e.getLocalizedMessage()),Toast.LENGTH_LONG).show()); }
    }

    @JavascriptInterface public void test() {
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE); Intent i=new Intent(c,AlarmReceiver.class).putExtra("id","-test").putExtra("kind",1);
        PendingIntent pi=PendingIntent.getBroadcast(c,7,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        try { if(am!=null) am.setAlarmClock(new AlarmManager.AlarmClockInfo(System.currentTimeMillis()+5000,pi),pi); } catch(SecurityException ignored) {}
    }
}
