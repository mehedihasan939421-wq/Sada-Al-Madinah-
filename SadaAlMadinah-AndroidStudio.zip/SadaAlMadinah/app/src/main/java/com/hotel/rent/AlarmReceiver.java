package com.hotel.rent;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;

public class AlarmReceiver extends BroadcastReceiver {
    private static String tr(String l, String bn, String ar, String en) {
        if ("ar".equals(l)) return ar;
        if ("en".equals(l)) return en;
        return bn;
    }

    @Override public void onReceive(Context c, Intent i) {
        String id = i.getStringExtra("id");
        if (id == null) return;
        int kind = i.getIntExtra("kind", 1);
        long end = i.getLongExtra("end", 0L);
        String l = Store.lang(c);
        String text;
        if ("-test".equals(id)) {
            text = tr(l, "এটি একটি টেস্ট অ্যালার্ম", "هذا منبّه تجريبي", "This is a test alarm");
        } else {
            Item item = null;
            for (Item x : Store.items(c)) if (id.equals(x.id)) { item = x; break; }
            if (item == null || item.end != end) return;
            String label = tr(l, "রুম ", "غرفة ", "Room ") + item.room;
            if (!item.name.isEmpty()) label += " — " + item.name;
            String msg = kind == 0
                    ? tr(l, "১০ মিনিটের মধ্যে মেয়াদ শেষ", "تنتهي المدة خلال ١٠ دقائق", "Expires within 10 minutes")
                    : tr(l, "মেয়াদ শেষ হয়েছে", "انتهت المدة", "Expired");
            text = label + " — " + msg;
        }
        NotificationManager nm = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        String ch = "rent_alarm";
        NotificationChannel chan = new NotificationChannel(ch, tr(l, "মেয়াদ অ্যালার্ম", "منبّه انتهاء المدة", "Rent expiry alarm"), NotificationManager.IMPORTANCE_HIGH);
        chan.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
        chan.enableVibration(true);
        chan.setVibrationPattern(new long[]{0,600,300,600});
        nm.createNotificationChannel(chan);
        PendingIntent open = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(c, ch)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(tr(l, "সাদা আল মদিনা", "صدى المدينة", "Sada Al Madinah"))
                .setContentText(text).setCategory(Notification.CATEGORY_ALARM)
                .setContentIntent(open).setFullScreenIntent(open, true).setAutoCancel(true).build();
        n.flags |= Notification.FLAG_INSISTENT;
        nm.notify((id.hashCode() & 0x3fffffff) + kind, n);
    }
}
