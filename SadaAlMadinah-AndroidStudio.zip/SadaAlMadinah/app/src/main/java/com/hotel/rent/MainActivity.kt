package com.hotel.rent

import android.Manifest
import android.app.*
import android.content.*
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.text.SpannableString
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

val WHITE = 0xFFFFFFFF.toInt()
val INK = 0xFF14302D.toInt()

fun nd(s: String): String {
    val d = if (L.ar) "٠١٢٣٤٥٦٧٨٩" else "০১২৩৪৫৬৭৮৯"
    return s.map { if (it in '0'..'9') d[it - '0'] else it }.joinToString("")
}

fun tk(x: Double): String = "৳" + nd(String.format(Locale.US, "%,.0f", abs(x)))

fun fmt(t: Long): String =
    nd(SimpleDateFormat("d MMM yyyy, h:mm a", if (L.ar) Locale("ar", "EG") else Locale("bn", "BD")).format(Date(t)))

fun fnum(x: Double): String = if (x == Math.floor(x)) x.toLong().toString() else x.toString()

fun left(r: Room): String {
    val ms = r.end - System.currentTimeMillis()
    if (ms <= 0) return L.t("over")
    val m = ms / 60000
    val d = m / 1440
    val h = m % 1440 / 60
    val mm = m % 60
    val dy = L.t("day")
    val hr = L.t("hour")
    val mi = L.t("min")
    val s = (if (d > 0) "$d $dy " else "") + (if (h > 0 || d > 0) "$h $hr " else "") + (if (d == 0L) "$mm $mi" else "")
    return nd(s).trim() + " " + L.t("remain")
}

class MainActivity : Activity() {
    private lateinit var rooms: MutableList<Room>
    private lateinit var adapter: ArrayAdapter<Room>
    private lateinit var sum: TextView
    private val dir: Int get() = if (L.ar) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR

    private fun font(): Typeface {
        if (L.ar) {
            val id = resources.getIdentifier("amiri", "font", packageName)
            return if (id != 0) resources.getFont(id) else Typeface.SERIF
        }
        return resources.getFont(R.font.kalpurush)
    }

    private fun tv(s: String, size: Float, bold: Boolean = false, color: Int = INK) = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        setTypeface(font(), if (bold) Typeface.BOLD else Typeface.NORMAL)
    }

    private fun btn(s: String, f: () -> Unit) = Button(this).apply {
        text = s
        setTypeface(font(), Typeface.BOLD)
        setOnClickListener { f() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        L.init(this)
        rooms = Store.load(this)
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xFF0F5C55.toInt())
            setPadding(32, 40, 32, 28)
            val names = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
            names.addView(tv("Sada Al Madinah", 24f, true, WHITE))
            names.addView(tv("Hotel Room Rent Hisab", 15f, true, WHITE))
            addView(names, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(btn(if (L.ar) "বাংলা" else "العربية") {
                L.set(this@MainActivity, !L.ar)
                recreate()
            })
        }
        sum = tv("", 16f, true).apply { setPadding(32, 24, 32, 8) }
        val list = ListView(this)
        adapter = object : ArrayAdapter<Room>(this, 0, rooms) {
            override fun getView(p: Int, v: View?, g: ViewGroup): View {
                val t = (v as? TextView) ?: TextView(context).apply {
                    setPadding(32, 24, 32, 24)
                    textSize = 16f
                    setTextColor(INK)
                    typeface = font()
                }
                val s = describe(getItem(p)!!)
                val sp = SpannableString(s)
                sp.setSpan(StyleSpan(Typeface.BOLD), 0, s.indexOf('\n'), 0)
                t.text = sp
                return t
            }
        }
        list.adapter = adapter
        list.setOnItemClickListener { _, _, p, _ -> menu(rooms[p]) }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = dir
            addView(head)
            addView(sum)
            addView(btn(L.t("add")) { edit(null) })
            addView(btn(L.t("test")) { testAlarm() })
            addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        })
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        rooms.forEach { Alarms.schedule(this, it) }
        tickLoop()
    }

    private fun tickLoop() {
        refresh()
        sum.postDelayed({ tickLoop() }, 30000)
    }

    private fun describe(r: Room): String {
        val due = r.due()
        val dueTxt = if (due > 0) L.t("due") + ": " + tk(due)
        else if (due < 0) L.t("extra") + ": " + tk(due)
        else L.t("settled")
        return L.t("room") + " " + nd(r.room) + "  •  " + left(r) + "\n" +
            L.t("start") + ": " + fmt(r.start) + "\n" +
            L.t("end") + ": " + fmt(r.end) + "\n" +
            nd(r.days().toString()) + " " + L.t("day") + " × " + tk(r.rate) + " = " + tk(r.total()) + "\n" +
            L.t("paid") + ": " + tk(r.paid) + "  |  " + dueTxt
    }

    private fun refresh() {
        adapter.notifyDataSetChanged()
        val a = rooms.sumOf { it.total() }
        val p = rooms.sumOf { it.paid }
        val sign = if (a - p < 0) "−" else ""
        sum.text = L.t("srent") + ": " + tk(a) + "   " + L.t("spaid") + ": " + tk(p) + "   " + L.t("sdue") + ": " + sign + tk(a - p)
    }

    private fun persist() {
        Store.save(this, rooms)
        refresh()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun show(b: AlertDialog.Builder): AlertDialog {
        val d = b.create()
        d.window?.decorView?.layoutDirection = dir
        d.show()
        return d
    }

    private fun menu(r: Room) {
        val items = arrayOf(L.t("edit"), "+" + nd("1") + " " + L.t("day"), "−" + nd("1") + " " + L.t("day"), L.t("del"))
        show(AlertDialog.Builder(this).setTitle(L.t("room") + " " + nd(r.room)).setItems(items) { _, w ->
            when (w) {
                0 -> edit(r)
                1 -> shift(r, DAY)
                2 -> shift(r, -DAY)
                3 -> show(AlertDialog.Builder(this).setMessage(L.t("dq1") + nd(r.room) + L.t("dq2"))
                    .setPositiveButton(L.t("yes")) { _, _ ->
                        Alarms.cancel(this, r)
                        rooms.remove(r)
                        persist()
                        toast(L.t("deleted"))
                    }.setNegativeButton(L.t("no"), null))
            }
        })
    }

    private fun shift(r: Room, d: Long) {
        if (r.end + d <= r.start) {
            toast(nd(L.t("minDay")))
            return
        }
        r.end += d
        Alarms.schedule(this, r)
        persist()
        toast(L.t(if (d > 0) "extT" else "decT"))
    }

    private fun pick(init: Long, cb: (Long) -> Unit) {
        val c = Calendar.getInstance().apply { timeInMillis = init }
        DatePickerDialog(this, { _, y, m, d ->
            TimePickerDialog(this, { _, h, mi ->
                val x = Calendar.getInstance()
                x.set(y, m, d, h, mi, 0)
                x.set(Calendar.MILLISECOND, 0)
                cb(x.timeInMillis)
            }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), false).show()
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun edit(r: Room?) {
        var st = r?.start ?: System.currentTimeMillis()
        var en = r?.end ?: (st + DAY)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0); layoutDirection = dir }
        val room = EditText(this).apply { hint = L.t("roomNo"); typeface = font(); setText(r?.room ?: "") }
        val bs = btn("") {}
        val be = btn("") {}
        fun upd() {
            bs.text = L.t("start") + ": " + fmt(st)
            be.text = L.t("end") + ": " + fmt(en)
        }
        bs.setOnClickListener { pick(st) { st = it; upd() } }
        be.setOnClickListener { pick(en) { en = it; upd() } }
        val num = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        val rate = EditText(this).apply {
            hint = L.t("rateL"); typeface = font(); inputType = num
            if (r != null && r.rate > 0) setText(fnum(r.rate))
        }
        val paid = EditText(this).apply {
            hint = L.t("paidL"); typeface = font(); inputType = num
            if (r != null && r.paid > 0) setText(fnum(r.paid))
        }
        upd()
        listOf<View>(room, bs, be, rate, paid).forEach { box.addView(it) }
        val dlg = AlertDialog.Builder(this).setTitle(if (r == null) L.t("newRoom") else L.t("editRoom")).setView(box)
            .setPositiveButton(L.t("save"), null).setNegativeButton(L.t("cancel"), null).create()
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val rn = room.text.toString().trim()
                if (rn.isEmpty()) toast(L.t("errRoom"))
                else if (en <= st) toast(L.t("errOrder"))
                else {
                    val rt = rate.text.toString().toDoubleOrNull() ?: 0.0
                    val pd = paid.text.toString().toDoubleOrNull() ?: 0.0
                    if (r == null) {
                        val nr = Room(Store.nextId(this), rn, st, en, rt, pd)
                        rooms.add(0, nr)
                        Alarms.schedule(this, nr)
                    } else {
                        r.room = rn; r.start = st; r.end = en; r.rate = rt; r.paid = pd
                        Alarms.schedule(this, r)
                    }
                    persist()
                    toast(L.t("saved"))
                    dlg.dismiss()
                }
            }
        }
        dlg.window?.decorView?.layoutDirection = dir
        dlg.show()
    }

    private fun testAlarm() {
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(this, 0, Intent(this, AlarmReceiver::class.java).putExtra("id", -1),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        am.setAlarmClock(AlarmManager.AlarmClockInfo(System.currentTimeMillis() + 5000, pi), pi)
        toast(L.t("testT"))
    }
}
