package com.hotel.rent

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.util.Base64
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF0F5C55.toInt()
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.blockNetworkLoads = true
        web.settings.loadsImagesAutomatically = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.scheme == "tel") {
                    startActivity(Intent(Intent.ACTION_DIAL, u))
                    return true
                }
                if (u.host == "wa.me" || u.scheme == "whatsapp") {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, u))
                    } catch (e: Exception) {
                    }
                    return true
                }
                return false
            }
        }
        web.addJavascriptInterface(Bridge(applicationContext, web), "Android")
        web.loadUrl("file:///android_asset/index.html")
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        askExact()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.__back&&window.__back())===true") { r ->
            if (r != "true") {
                if (web.canGoBack()) web.goBack() else finish()
            }
        }
    }

    private fun askExact() {
        if (Build.VERSION.SDK_INT >= 31) {
            val am = getSystemService(ALARM_SERVICE) as AlarmManager
            if (!am.canScheduleExactAlarms()) {
                try {
                    startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
                } catch (e: Exception) {
                }
            }
        }
    }
}

class Bridge(private val c: Context, private val web: WebView) {
    private fun parseEnd(s: String): Long = try {
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).parse(s)?.time ?: 0L
    } catch (e: Exception) {
        0L
    }

    @JavascriptInterface
    fun sync(json: String) {
        try {
            val o = JSONObject(json)
            val lang = o.optString("lang", "bn")
            val arr = o.getJSONArray("rooms")
            val list = mutableListOf<Item>()
            for (i in 0 until arr.length()) {
                val r = arr.getJSONObject(i)
                val end = parseEnd(r.optString("end"))
                if (end > 0) list.add(Item(r.getString("id"), r.optString("room"), r.optString("name"), end))
            }
            Alarms.sync(c, lang, list)
        } catch (e: Exception) {
        }
    }

    @JavascriptInterface
    fun print(title: String) {
        web.post {
            try {
                val pm = web.context.getSystemService(Context.PRINT_SERVICE) as PrintManager
                val name = if (title.isBlank()) "Receipt" else title
                pm.print(name, web.createPrintDocumentAdapter(name), PrintAttributes.Builder().build())
            } catch (e: Exception) {
            }
        }
    }

    @JavascriptInterface
    fun share(text: String) {
        try {
            val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
            c.startActivity(Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
        }
    }

    private val imageBuffer = StringBuilder()

    @JavascriptInterface
    @Synchronized
    fun beginShareImage() {
        imageBuffer.setLength(0)
    }

    @JavascriptInterface
    @Synchronized
    fun appendShareImageChunk(chunk: String) {
        // WebView-to-native bridge transfers bounded chunks instead of one large Base64 string.
        if (chunk.length > 65536) throw IllegalArgumentException("Image chunk is too large")
        if (imageBuffer.length + chunk.length > 20 * 1024 * 1024) {
            imageBuffer.setLength(0)
            throw IllegalArgumentException("Welcome card image is too large")
        }
        imageBuffer.append(chunk)
    }

    @JavascriptInterface
    @Synchronized
    fun cancelShareImage() {
        imageBuffer.setLength(0)
    }

    @JavascriptInterface
    @Synchronized
    fun finishShareImage() {
        try {
            val encoded = imageBuffer.toString()
            imageBuffer.setLength(0)
            if (encoded.isBlank()) throw IllegalArgumentException("ছবির ডেটা পাওয়া যায়নি")
            val bytes = Base64.decode(encoded, Base64.DEFAULT)
            if (bytes.isEmpty()) throw IllegalArgumentException("ছবিটি খালি")

            // Temporary cache file only; never saved to Gallery or Downloads.
            val dir = File(c.cacheDir, "shared").apply { mkdirs() }
            // Keep only one temporary card image; never create multiple share attachments.
            dir.listFiles()?.forEach { it.delete() }
            val file = File(dir, "welcome-${System.currentTimeMillis()}.jpg")
            file.writeBytes(bytes)
            val uri = FileProvider.getUriForFile(c, c.packageName + ".fileprovider", file)

            val send = Intent(Intent.ACTION_SEND).apply {
                type = "image/jpeg"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            val pm = c.packageManager
            val targetPackage = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull { pkg ->
                try {
                    if (Build.VERSION.SDK_INT >= 33) {
                        pm.getPackageInfo(pkg, android.content.pm.PackageManager.PackageInfoFlags.of(0))
                    } else {
                        @Suppress("DEPRECATION")
                        pm.getPackageInfo(pkg, 0)
                    }
                    true
                } catch (_: Exception) { false }
            }
            if (targetPackage != null) send.setPackage(targetPackage)

            web.post {
                try {
                    if (targetPackage != null) {
                        try {
                            c.startActivity(send)
                        } catch (_: Exception) {
                            send.setPackage(null)
                            c.startActivity(Intent.createChooser(send, "WhatsApp-এ ছবি পাঠান")
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION))
                        }
                    } else {
                        c.startActivity(Intent.createChooser(send, "Welcome card শেয়ার করুন")
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION))
                    }
                } catch (e: Exception) {
                    Toast.makeText(c, "শেয়ার চালু করা যায়নি: ${e.localizedMessage ?: "অজানা সমস্যা"}", Toast.LENGTH_LONG).show()
                }
            }
        } catch (e: Exception) {
            imageBuffer.setLength(0)
            web.post {
                Toast.makeText(c, "ছবি প্রস্তুত করা যায়নি: ${e.localizedMessage ?: "অজানা সমস্যা"}", Toast.LENGTH_LONG).show()
            }
        }
    }

    @JavascriptInterface
    fun test() {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val i = Intent(c, AlarmReceiver::class.java).putExtra("id", "-test").putExtra("kind", 1)
        val pi = PendingIntent.getBroadcast(c, 7, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        try {
            am.setAlarmClock(AlarmManager.AlarmClockInfo(System.currentTimeMillis() + 5000, pi), pi)
        } catch (e: SecurityException) {
        }
    }
}
