package com.hotel.rent

import android.app.*
import android.content.*
import android.media.AudioAttributes
import android.media.RingtoneManager
import org.json.JSONArray
import org.json.JSONObject


object L {
    var ar = false
    fun init(c: Context) { ar = c.getSharedPreferences("rooms", Context.MODE_PRIVATE).getBoolean("ar", false) }
    fun set(c: Context, v: Boolean) {
        ar = v
        c.getSharedPreferences("rooms", Context.MODE_PRIVATE).edit().putBoolean("ar", v).apply()
    }
    private val m = mapOf(
        "add" to ("+ নতুন রুম যোগ করুন" to "+ إضافة غرفة جديدة"),
        "test" to ("অ্যালার্ম টেস্ট (৫ সেকেন্ড)" to "تجربة المنبّه (٥ ثوانٍ)"),
        "srent" to ("মোট ভাড়া" to "إجمالي الإيجار"),
        "spaid" to ("মোট জমা" to "إجمالي المدفوع"),
        "sdue" to ("মোট বাকি" to "إجمالي المتبقي"),
        "room" to ("রুম" to "غرفة"),
        "day" to ("দিন" to "يوم"),
        "hour" to ("ঘণ্টা" to "ساعة"),
        "min" to ("মিনিট" to "دقيقة"),
        "remain" to ("বাকি" to "متبقي"),
        "over" to ("মেয়াদ শেষ" to "انتهت المدة"),
        "start" to ("শুরু" to "البداية"),
        "end" to ("শেষ" to "النهاية"),
        "paid" to ("জমা" to "المدفوع"),
        "due" to ("বাকি" to "المتبقي"),
        "extra" to ("অতিরিক্ত জমা" to "دفعة زائدة"),
        "settled" to ("পরিশোধিত ✓" to "مدفوع بالكامل ✓"),
        "edit" to ("এডিট" to "تعديل"),
        "del" to ("মুছুন" to "حذف"),
        "yes" to ("হ্যাঁ, মুছুন" to "نعم، احذف"),
        "no" to ("না" to "لا"),
        "newRoom" to ("নতুন রুম" to "غرفة جديدة"),
        "editRoom" to ("রুম এডিট" to "تعديل الغرفة"),
        "roomNo" to ("রুম নং" to "رقم الغرفة"),
        "rateL" to ("একদিনের ভাড়া (টাকা)" to "إيجار اليوم الواحد (تاكا)"),
        "paidL" to ("জমা (টাকা)" to "المدفوع (تاكا)"),
        "save" to ("সেভ করুন" to "حفظ"),
        "cancel" to ("বাতিল" to "إلغاء"),
        "errRoom" to ("রুম নং লিখুন" to "أدخل رقم الغرفة"),
        "errOrder" to ("শেষ সময় শুরুর সময়ের পরে হতে হবে" to "يجب أن تكون النهاية بعد البداية"),
        "saved" to ("সেভ হয়েছে" to "تم الحفظ"),
        "deleted" to ("রুম মুছে ফেলা হয়েছে" to "تم حذف الغرفة"),
        "minDay" to ("আর কমানো যাবে না, কমপক্ষে ১ দিন থাকতে হবে" to "لا يمكن الإنقاص أكثر، يجب أن يبقى يوم واحد على الأقل"),
        "extT" to ("১ দিন বাড়ানো হয়েছে" to "تمت إضافة يوم"),
        "decT" to ("১ দিন কমানো হয়েছে" to "تم إنقاص يوم"),
        "dq1" to ("রুম " to "هل تريد حذف الغرفة "),
        "dq2" to (" মুছে ফেলবেন?" to "؟"),
        "testT" to ("৫ সেকেন্ডে অ্যালার্ম বাজবে — অ্যাপ বন্ধ করে দেখুন" to "سيرنّ المنبّه بعد ٥ ثوانٍ — أغلق التطبيق وراقب"),
        "testMsg" to ("এটি একটি টেস্ট অ্যালার্ম" to "هذا منبّه تجريبي"),
        "pre" to ("১০ মিনিটের মধ্যে মেয়াদ শেষ" to "تنتهي المدة خلال ١٠ دقائق"),
        "fin" to ("মেয়াদ শেষ হয়েছে" to "انتهت المدة"),
        "ch" to ("মেয়াদ অ্যালার্ম" to "منبّه انتهاء المدة")
    )
    fun t(k: String): String = m[k]?.let { if (ar) it.second else it.first } ?: k
}

const val MIN10 = 600000L
const val DAY = 86400000L

data class Room(var id: Int, var room: String, var start: Long, var end: Long, var rate: Double, var paid: Double) {
    fun days(): Long = if (end > start) Math.ceil((end - start).toDouble() / DAY - 1e-9).toLong() else 0L
    fun total(): Double = rate * days()
    fun due(): Double = total() - paid
}

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("rooms", Context.MODE_PRIVATE)

    fun load(c: Context): MutableList<Room> {
        val out = mutableListOf<Room>()
        try {
            val a = JSONArray(sp(c).getString("list", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Room(o.getInt("id"), o.getString("room"), o.getLong("start"), o.getLong("end"), o.getDouble("rate"), o.getDouble("paid")))
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun save(c: Context, l: List<Room>) {
        val a = JSONArray()
        l.forEach {
            a.put(JSONObject().put("id", it.id).put("room", it.room).put("start", it.start).put("end", it.end).put("rate", it.rate).put("paid", it.paid))
        }
        sp(c).edit().putString("list", a.toString()).apply()
    }

    fun nextId(c: Context): Int {
        val n = sp(c).getInt("next", 1)
        sp(c).edit().putInt("next", n + 1).apply()
        return n
    }
}

object Alarms {
    private fun pi(c: Context, r: Room, kind: Int): PendingIntent {
        val i = Intent(c, AlarmReceiver::class.java).putExtra("id", r.id).putExtra("kind", kind).putExtra("end", r.end)
        return PendingIntent.getBroadcast(c, r.id * 2 + kind, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun cancel(c: Context, r: Room) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pi(c, r, 0))
        am.cancel(pi(c, r, 1))
    }

    fun schedule(c: Context, r: Room) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val show = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val now = System.currentTimeMillis()
        cancel(c, r)
        if (r.end - MIN10 > now) am.setAlarmClock(AlarmManager.AlarmClockInfo(r.end - MIN10, show), pi(c, r, 0))
        if (r.end > now) am.setAlarmClock(AlarmManager.AlarmClockInfo(r.end, show), pi(c, r, 1))
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        L.init(c)
        val id = i.getIntExtra("id", -1)
        val kind = i.getIntExtra("kind", 1)
        val end = i.getLongExtra("end", 0L)
        val r = Store.load(c).firstOrNull { it.id == id }
        if (id != -1 && (r == null || r.end != end)) return
        val text = if (id == -1) L.t("testMsg")
        else L.t("room") + " " + nd(r!!.room) + " — " + (if (kind == 0) L.t("pre") else L.t("fin"))
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = "rent_alarm"
        val chan = NotificationChannel(ch, L.t("ch"), NotificationManager.IMPORTANCE_HIGH)
        chan.setSound(
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        )
        chan.enableVibration(true)
        chan.vibrationPattern = longArrayOf(0, 600, 300, 600)
        nm.createNotificationChannel(chan)
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(c, ch)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Sada Al Madinah")
            .setContentText(text)
            .setCategory(Notification.CATEGORY_ALARM)
            .setContentIntent(open)
            .setFullScreenIntent(open, true)
            .setAutoCancel(true)
            .build()
        n.flags = n.flags or Notification.FLAG_INSISTENT
        nm.notify(id * 2 + kind, n)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Store.load(c).forEach { Alarms.schedule(c, it) }
    }
}
