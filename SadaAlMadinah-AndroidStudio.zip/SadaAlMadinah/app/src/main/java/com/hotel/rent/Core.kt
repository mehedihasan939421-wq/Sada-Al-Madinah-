package com.hotel.rent

import android.app.*
import android.content.*
import android.media.AudioAttributes
import android.media.RingtoneManager
import org.json.JSONArray
import org.json.JSONObject

const val MIN10 = 600000L

data class Item(val id: String, val room: String, val name: String, val end: Long)

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("hotel", Context.MODE_PRIVATE)

    fun lang(c: Context): String = sp(c).getString("lang", "bn") ?: "bn"

    fun items(c: Context): List<Item> {
        val out = mutableListOf<Item>()
        try {
            val a = JSONArray(sp(c).getString("items", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Item(o.getString("id"), o.getString("room"), o.getString("name"), o.getLong("end")))
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun save(c: Context, lang: String, list: List<Item>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("id", it.id).put("room", it.room).put("name", it.name).put("end", it.end)) }
        sp(c).edit().putString("lang", lang).putString("items", a.toString()).apply()
    }
}

object Alarms {
    private fun pi(c: Context, it: Item, kind: Int): PendingIntent {
        val code = (it.id.hashCode() and 0x3fffffff) * 2 + kind
        val i = Intent(c, AlarmReceiver::class.java).putExtra("id", it.id).putExtra("kind", kind).putExtra("end", it.end)
        return PendingIntent.getBroadcast(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun cancelAll(c: Context, list: List<Item>) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        list.forEach {
            am.cancel(pi(c, it, 0))
            am.cancel(pi(c, it, 1))
        }
    }

    fun scheduleAll(c: Context, list: List<Item>) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val show = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val now = System.currentTimeMillis()
        list.forEach {
            try {
                if (it.end - MIN10 > now) am.setAlarmClock(AlarmManager.AlarmClockInfo(it.end - MIN10, show), pi(c, it, 0))
                if (it.end > now) am.setAlarmClock(AlarmManager.AlarmClockInfo(it.end, show), pi(c, it, 1))
            } catch (e: SecurityException) {
            }
        }
    }

    fun sync(c: Context, lang: String, list: List<Item>) {
        cancelAll(c, Store.items(c))
        Store.save(c, lang, list)
        scheduleAll(c, list)
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getStringExtra("id") ?: return
        val kind = i.getIntExtra("kind", 1)
        val end = i.getLongExtra("end", 0L)
        val l = Store.lang(c)
        fun tr(bn: String, ar: String, en: String) = when (l) { "ar" -> ar; "en" -> en; else -> bn }
        val text: String
        if (id == "-test") {
            text = tr("এটি একটি টেস্ট অ্যালার্ম", "هذا منبّه تجريبي", "This is a test alarm")
        } else {
            val it = Store.items(c).firstOrNull { x -> x.id == id } ?: return
            if (it.end != end) return
            val label = tr("রুম ", "غرفة ", "Room ") + it.room + (if (it.name.isNotEmpty()) " — " + it.name else "")
            val msg = if (kind == 0) tr("১০ মিনিটের মধ্যে মেয়াদ শেষ", "تنتهي المدة خلال ١٠ دقائق", "Expires within 10 minutes")
            else tr("মেয়াদ শেষ হয়েছে", "انتهت المدة", "Expired")
            text = label + " — " + msg
        }
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = "rent_alarm"
        val chan = NotificationChannel(ch, tr("মেয়াদ অ্যালার্ম", "منبّه انتهاء المدة", "Rent expiry alarm"), NotificationManager.IMPORTANCE_HIGH)
        chan.setSound(
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        )
        chan.enableVibration(true)
        chan.vibrationPattern = longArrayOf(0, 600, 300, 600)
        nm.createNotificationChannel(chan)
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(c, ch)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(tr("সাদা আল মদিনা", "صدى المدينة", "Sada Al Madinah"))
            .setContentText(text)
            .setCategory(Notification.CATEGORY_ALARM)
            .setContentIntent(open)
            .setFullScreenIntent(open, true)
            .setAutoCancel(true)
            .build()
        n.flags = n.flags or Notification.FLAG_INSISTENT
        nm.notify((id.hashCode() and 0x3fffffff) + kind, n)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Alarms.scheduleAll(c, Store.items(c))
    }
}
