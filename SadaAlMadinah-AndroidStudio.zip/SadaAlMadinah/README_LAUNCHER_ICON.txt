অ্যাপ ড্রয়ারের আসল লঞ্চার আইকন

Android-এ ইনস্টল করা অ্যাপ নিজের মতো করে runtime-এ package launcher icon বদলাতে পারে না। তাই আসল App Drawer icon build করার সময় APK-এর মধ্যে ঢুকাতে হবে।

ব্যবহার:
1. প্রজেক্টের root-এ আপনার লোগো রাখুন: app_logo.png
2. GitHub Actions build চালান। workflow স্বয়ংক্রিয়ভাবে app_logo.png-কে launcher icon resource হিসেবে ব্যবহার করবে।
3. নতুন APK ইনস্টল করলে App Drawer-এ সেই লোগো দেখা যাবে।

সুপারিশ: square PNG, 1024x1024 px, transparent background হলে ভালো।

মেনুবারে আলাদা লোগো সেট করার অপশন রাখা হয়নি। `app_logo.png` বদলে নতুন APK build করলে App Drawer-এর launcher icon বদলাবে।
