#!/usr/bin/env python3
from pathlib import Path
import shutil, sys
root = Path(__file__).resolve().parents[1]
out = root / 'app/src/main/res/drawable-nodpi/app_launcher_icon.png'
if len(sys.argv) != 2:
    print('Usage: python3 tools/set_launcher_icon.py /path/to/logo.png')
    raise SystemExit(2)
src = Path(sys.argv[1])
if not src.is_file():
    raise SystemExit(f'Logo not found: {src}')
if src.suffix.lower() not in {'.png', '.jpg', '.jpeg', '.webp'}:
    raise SystemExit('Logo must be PNG, JPG, JPEG, or WebP')
shutil.copyfile(src, out)
print(f'Launcher icon updated: {out}')
