Sada Al Madinah — Welcome Card Update

Confirmed behavior in this update:
- Saving a new hotel name updates the app header and persists it in WebView localStorage.
- The welcome-card JPG is regenerated immediately if the welcome card is open when the hotel name is saved.
- The generated welcome-card image and greeting text both read the current translated hotel name.
- A render sequence guard prevents an older, slower JPG render from replacing the newly updated card.
- Changing language also refreshes an open welcome card.
- The compact 34 x 34 px menu is aligned to the top-right.
- Language options: বাংলা, English, العربية.
- GitHub Actions workflow is at .github/workflows/build-apk.yml.

Upload the CONTENTS of the SadaAlMadinah folder to the repository root, then run:
GitHub > Actions > Build Sada Al Madinah APK > Run workflow.

Workflow produces a debug APK. Android build has not been executed here; inspect GitHub Actions for the actual build result.
